/*
 * ContactMatrix.cpp
 *
 *  Created on: Oct 16, 2009
 *      Author: goto
 */

#include "ContactMatrix.h"

namespace pmw
{

CContactMatrix::CContactMatrix()
{
	// TODO Auto-generated constructor stub

}

CContactMatrix::~CContactMatrix()
{
	// TODO Auto-generated destructor stub
}

void CContactMatrix::multVectorAdd(CAssyVector *pP, CAssyVector *pX)
{
	// TODO implement CContactMatrix::multVectorAdd
	// p += Ac x
}

}
