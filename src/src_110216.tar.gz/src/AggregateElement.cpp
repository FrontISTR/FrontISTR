//
//  AggregateElement.cpp
//
//
//
//                              2009.05.29
//                              2009.05.29
//                              k.Takeda
#include "AggregateElement.h"
using namespace pmw;

CAggregateElement::CAggregateElement()
{
    ;
}
CAggregateElement::~CAggregateElement()
{
    ////debug
    //cout << "~CAggregateElement" << endl;
}








