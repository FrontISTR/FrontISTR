//
//  BNodeMeshGrp.cpp
//
//              2010.06.25
//              k.Takeda
#include "BNodeMeshGrp.h"
using namespace pmw;


CBNodeMeshGrp::CBNodeMeshGrp()
{
    ;
}
CBNodeMeshGrp::~CBNodeMeshGrp()
{
    ;
}















