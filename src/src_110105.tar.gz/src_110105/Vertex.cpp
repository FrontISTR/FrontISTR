//
// Vertex.cpp
//				2008.12.18
//				2008.12.18
//				k.Takeda
#include "Vertex.h"
using namespace pmw;

#include <iostream>
//
//
CVertex::CVertex(void)
{
    // mID = -1;// not initialize
    //mRank= -1;// non initialize
}

CVertex::~CVertex(void)
{
//    //debug
//    std::cout << "~CVertex" << std::endl;
}
