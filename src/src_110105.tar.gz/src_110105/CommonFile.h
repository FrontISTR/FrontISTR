/* 
 * File:   CommonFile.h
 * Author: ktakeda
 *
 * Created on 2009/05/08, 17:03
 */

#ifndef _COMMONFILE_H_053b3422_8dd5_404f_b06d_0d7a697c4cf3
#define	_COMMONFILE_H_053b3422_8dd5_404f_b06d_0d7a697c4cf3

#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

#endif	/* _COMMONFILE_H */

