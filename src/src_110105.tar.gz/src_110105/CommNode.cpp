//
//  CommNode.cpp
//
//
//
//
//          2010.03.02
//          k.Takeda
#include "CommNode.h"
using namespace pmw;

CCommNode::CCommNode()
{
    ;
}
CCommNode::~CCommNode()
{
    ;
}











